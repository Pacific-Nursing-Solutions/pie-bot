#!/usr/bin/env python3
"""
equity_split_tool.py

A utility for:
  - Generating dynamic equity splits for a "grunt fund" (weighted formula)
  - Building formal priced-round cap tables with option pools
  - Recommending entity structure (C-Corp vs LLC/Partnership)
  - Connecting to financial and CRM platforms (HubSpot, QuickBooks, Xero)
  - Guiding through corporate filings and 1099 generation

Provides:
  - Command-Line Interface (CLI) with interactive mode
  - FastAPI HTTP API with health and generate endpoints
  - Config file support for default parameters
  - Plugin connectivity checks and data fetching stubs
  - Logging and error handling
  - Interactive Q&A flow for weight adjustments and filing guidance
"""
import os
import sys
import json
import argparse
import logging
from pathlib import Path

import openai
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# === Logging Setup ===
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("EquitySplitTool")

# === Constants ===
DEFAULT_CONFIG_PATH = Path.home() / ".equity_split_config.json"

# === Load Config ===
def load_config(path: Path = DEFAULT_CONFIG_PATH) -> dict:
    if path.exists():
        try:
            cfg = json.loads(path.read_text())
            logger.info(f"Loaded config from {path}")
            return cfg
        except Exception as e:
            logger.error(f"Failed to parse config: {e}")
    return {}

# === OpenAI Setup ===
openai.api_key = os.getenv("OPENAI_API_KEY")

# === Data Models ===
class EquityRequest(BaseModel):
    path: str = Field(..., regex="^(grunt|funded)$")
    params: dict
    use_hubspot: bool = False
    use_quickbooks: bool = False
    use_xero: bool = False

# === Plugin Connectors (Stubs) ===
def connect_hubspot():
    api_key = os.getenv("HUBSPOT_API_KEY")
    if not api_key:
        logger.warning("HUBSPOT_API_KEY not set")
        return None
    return "HubSpotClient"

def connect_quickbooks():
    creds = os.getenv("QUICKBOOKS_CREDENTIALS_JSON")
    if not creds:
        logger.warning("QUICKBOOKS_CREDENTIALS_JSON not set")
        return None
    return "QuickBooksClient"

def connect_xero():
    creds = os.getenv("XERO_CREDENTIALS_JSON")
    if not creds:
        logger.warning("XERO_CREDENTIALS_JSON not set")
        return None
    return "XeroClient"

# === Prompt Builder ===
def build_prompt(path: str, params: dict) -> str:
    intro = (
        "You are an expert assistant with comprehensive knowledge of the user's company equity, "
        "corporate filings, and connected CRM/accounting data."
    )
    entity_section = (
        "Recommend whether a C-Corporation or an LLC/Partnership is optimal, "
        "including tax, governance, and 1099 considerations."
    )
    filing_section = (
        "Check corporate filings: if formation documents aren't complete, "
        "prompt user with next steps. Ensure 1099s are prepared for contractors."
    )

    if path == 'grunt':
        contributors = json.dumps(params.get('contributors', {}))
        weights = json.dumps(params.get('weights', {'capital': 1.0, 'time': 1.0, 'idea': 0.5}))
        return (
            f"{intro}\n"
            "--- DYNAMIC EQUITY PATH ---\n"
            "Use weighted formula: share_i = (w_capital*C + w_time*T + w_idea*I ...)/total.\n"
            f"Contributors: {contributors}\n"
            f"Weights: {weights}\n"
            "Allow interactive weight and contributor adjustments.\n"
            f"{entity_section}\n{filing_section}"
        )

    pre = params.get('pre_money')
    raise_amt = params.get('raise_amount')
    pool = params.get('option_pool')
    founders = json.dumps(params.get('founders_split', {}))
    investors = json.dumps(params.get('investors', {}))
    return (
        f"{intro}\n"
        "--- FUNDED EQUITY PATH ---\n"
        f"Pre-money: {pre} USD, Raise: {raise_amt} USD, Option pool: {pool}% post-money.\n"
        f"Founders: {founders}\n"
        f"Investors: {investors}\n"
        "Compute post-money cap table with all equity classes and rights.\n"
        f"{entity_section}\n{filing_section}"
    )

# === ChatGPT Invocation ===
def call_chatgpt(prompt: str) -> str:
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant specializing in equity, entity structure, and integrations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1200
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"ChatGPT API error: {e}")
        raise

# === CLI ===
def run_cli():
    config = load_config()
    parser = argparse.ArgumentParser(
        description="Equity split & structuring tool with integrations and interactive mode"
    )
    parser.add_argument("--path", choices=['grunt', 'funded'], required=True)
    parser.add_argument("--params", type=str,
                        default=json.dumps(config.get('default_params', {})),
                        help="JSON string of parameters.")
    parser.add_argument("--config", type=str, help="Path to JSON config file.")
    parser.add_argument("--interactive", action="store_true",
                        help="Enable interactive Q&A for tweaking weights/filings.")
    parser.add_argument("--use-hubspot", action="store_true")
    parser.add_argument("--use-quickbooks", action="store_true")
    parser.add_argument("--use-xero", action="store_true")
    args = parser.parse_args()

    if args.config:
        config = load_config(Path(args.config))

    try:
        params = json.loads(args.params)
    except json.JSONDecodeError:
        logger.error("Invalid JSON for --params")
        sys.exit(1)

    if args.use_hubspot:
        hub = connect_hubspot()
    if args.use_quickbooks:
        qb = connect_quickbooks()
    if args.use_xero:
        xr = connect_xero()

    prompt = build_prompt(args.path, params)
    logger.info("Generated prompt, invoking ChatGPT...")
    result = call_chatgpt(prompt)
    print("\n=== ChatGPT Response ===\n", result)

    if args.interactive:
        while True:
            resp = input("\nAdjust weights or contributors? (yes/no): ")
            if resp.strip().lower() != 'yes':
                break
            key = input("Enter weight key to adjust (capital/time/idea): ")
            val = input(f"Enter new weight for {key}: ")
            try:
                params['weights'][key] = float(val)
            except Exception:
                print("Invalid weight, try again.")
                continue
            prompt = build_prompt(args.path, params)
            result = call_chatgpt(prompt)
            print("\n=== Updated Response ===\n", result)

# === FastAPI ===
app = FastAPI(title="EquitySplitTool API", version="2.1.0")

@app.get("/health")
async def health_check():
    return {"status": "ok"}

@app.post("/generate")
async def generate_equity(req: EquityRequest):
    try:
        prompt = build_prompt(req.path, req.params)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    content = call_chatgpt(prompt)
    return {"prompt": prompt, "result": content}

if __name__ == '__main__':
    run_cli()
