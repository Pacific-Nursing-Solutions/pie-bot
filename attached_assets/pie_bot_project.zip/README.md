## pie.bot – Equity Split Tool

A unified toolkit for:

- **Dynamic “grunt fund”** equity splits (weighted formulas)
- **Priced-round** cap tables (common, preferred, SAFEs/notes, option pools)
- **Entity recommendations** (C-Corp vs LLC/Partnership)
- **Integrations** with HubSpot, QuickBooks, Xero, Hubstaff
- **Corporate filings** guidance and 1099 generation

---

### 🗂️ File Structure

```
.
├── .replit
├── equity_split_tool.py      # Main script (CLI + FastAPI API)
├── requirements.txt          # Python dependencies
├── README.md                 # This file
└── equity_split_config.json? # Optional user config (seeded by CLI)
```

---

### 🛠️ Dependencies

```
fastapi
uvicorn
pydantic
openai
```

---

### 🔧 Environment Variables

Set these in **Secrets** (Replit “Environment”):

- `OPENAI_API_KEY`
- `HUBSPOT_API_KEY` (if using HubSpot)
- `QUICKBOOKS_CREDENTIALS_JSON` (if using QuickBooks)
- `XERO_CREDENTIALS_JSON` (if using Xero)

---

### 🚀 Running Locally on Replit

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Start the HTTP API**
   ```bash
   uvicorn equity_split_tool:app --host=0.0.0.0 --port=3000
   ```
   - Health check: `GET /health` → `{ "status": "ok" }`
   - Generate split: `POST /generate` with JSON body:
     ```json
     {
       "path": "grunt",
       "params": {
         "contributors": {"Alice": 50, "Bob": 50},
         "weights": {"capital":1.0,"time":1.0,"idea":0.5}
       },
       "use_hubspot": false
     }
     ```

3. **Use the CLI**
   ```bash
   python equity_split_tool.py --path grunt      --params '{"contributors":{"Alice":50},"weights":{"capital":1,"time":2,"idea":0.5}}'      --interactive
   ```
